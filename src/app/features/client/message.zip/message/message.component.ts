import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { NgIconComponent, provideIcons } from '@ng-icons/core';
import { 
  heroBold, 
  heroItalic,
  heroUnderline,
  heroStrikethrough,
  heroCodeBracket,
  heroDocument,
  heroListBullet,
  heroArrowUturnLeft,
  heroArrowUturnRight,
  heroChevronLeft,
  heroChevronRight,
  heroChevronDoubleLeft,
  heroChevronDoubleRight,
  heroDocumentText,
  heroDocumentDuplicate,
  heroMinusSmall,
  heroMinus
} from '@ng-icons/heroicons/outline';
import { ToasterService } from '../../../core/services/toaster.service';

@Component({
  selector: 'app-message',
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    NgIconComponent
  ],
  providers: [
    provideIcons({
      heroBold,
      heroItalic,
      heroUnderline,
      heroStrikethrough,
      heroCodeBracket,
      heroDocument,
      heroListBullet,
      heroArrowUturnLeft,
      heroArrowUturnRight,
      heroChevronLeft,
      heroChevronRight,
      heroChevronDoubleLeft,
      heroChevronDoubleRight,
      heroDocumentText,
      heroDocumentDuplicate,
      heroMinusSmall,
      heroMinus
    })
  ],
  templateUrl: './message.component.html'
})
export class MessageComponent implements OnInit {
  @ViewChild('editor') editor!: ElementRef;
  content: string = '';
  currentAlignment: 'left' | 'center' | 'right' = 'left';
  private undoStack: string[] = [];
  private redoStack: string[] = [];

  constructor(private toaster: ToasterService) {}

  ngOnInit() {
    setTimeout(() => {
      if (this.editor && this.editor.nativeElement) {
        if (!this.editor.nativeElement.innerHTML) {
          this.editor.nativeElement.innerHTML = '<p><br></p>';
        }
        this.editor.nativeElement.style.direction = 'ltr';
        this.editor.nativeElement.style.unicodeBidi = 'embed';
        
        const range = document.createRange();
        const sel = window.getSelection();
        const firstChild = this.editor.nativeElement.firstChild;
        if (firstChild) {
          range.setStart(firstChild, 0);
          range.collapse(true);
          sel?.removeAllRanges();
          sel?.addRange(range);
        }
      }
    });
  }

  formatText(command: string, value?: string) {
    this.saveState();
    
    if (command.startsWith('justify')) {
      this.currentAlignment = command.toLowerCase().replace('justify', '') as 'left' | 'center' | 'right';
      document.execCommand(command, false, value);
    } else {
      document.execCommand(command, false, value);
    }
    
    this.editor.nativeElement.focus();
  }

  isFormatActive(command: string): boolean {
    return document.queryCommandState(command);
  }

  onContentChange(event: Event) {
    const target = event.target as HTMLDivElement;
    const selection = window.getSelection();
    const range = selection?.getRangeAt(0);
    const offset = range?.startOffset || 0;
    
    this.content = target.innerHTML;
    this.saveState();
    
    if (selection && range) {
      const newRange = document.createRange();
      newRange.setStart(range.startContainer, offset);
      newRange.collapse(true);
      selection.removeAllRanges();
      selection.addRange(newRange);
    }
  }

  handleKeyDown(event: KeyboardEvent) {
    if (event.key === 'Tab') {
      event.preventDefault();
      this.formatText('insertHTML', '&nbsp;&nbsp;&nbsp;&nbsp;');
    }

    if (event.ctrlKey || event.metaKey) {
      switch (event.key.toLowerCase()) {
        case 'z':
          event.preventDefault();
          if (event.shiftKey) {
            this.redo();
          } else {
            this.undo();
          }
          break;
        case 'y':
          event.preventDefault();
          this.redo();
          break;
      }
    }
  }

  private saveState() {
    this.undoStack.push(this.content);
    this.redoStack = [];
  }

  undo() {
    if (this.undoStack.length > 1) {
      const current = this.undoStack.pop();
      if (current) {
        this.redoStack.push(current);
        this.content = this.undoStack[this.undoStack.length - 1];
        this.editor.nativeElement.innerHTML = this.content;
      }
    }
  }

  redo() {
    const state = this.redoStack.pop();
    if (state) {
      this.undoStack.push(state);
      this.content = state;
      this.editor.nativeElement.innerHTML = this.content;
    }
  }

  clearContent() {
    this.saveState();
    this.content = '';
    this.editor.nativeElement.innerHTML = '';
    this.resetAlignment();
  }

  saveContent() {
    if (this.content) {
      console.log('Content to save:', this.content);
      this.toaster.success('MESSAGE.SUCCESS.SAVED');
    }
  }

  getCurrentAlignment(): string {
    return this.currentAlignment;
  }

  resetAlignment() {
    this.currentAlignment = 'left';
    this.formatText('justifyLeft');
  }
}
